#ifndef STRUCT_DESCRITOR_ARVORE_H
#define STRUCT_DESCRITOR_ARVORE_H
#include "../ArvoreBinaria.h"
struct dArvore{
    pNohArvore raiz;
    int        quantidadeNohs;
    int        grau;
};


#endif
