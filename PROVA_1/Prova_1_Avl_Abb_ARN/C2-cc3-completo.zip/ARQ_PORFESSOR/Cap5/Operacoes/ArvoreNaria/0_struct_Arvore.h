#ifndef STRUCT_ARVORE_H
#define STRUCT_ARVORE_H
#include "../../ArvoreNaria.h"
struct nohArvore{
   void*      info;
   pDLista    filhos;
};

#endif
