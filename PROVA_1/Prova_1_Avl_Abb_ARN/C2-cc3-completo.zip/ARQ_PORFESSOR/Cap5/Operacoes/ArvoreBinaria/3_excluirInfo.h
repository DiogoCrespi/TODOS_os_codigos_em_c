#ifndef EXCLUIRINFO_ARVORE_BINARIA_H
#define EXCLUIRINFO_ARVORE_BINARIA_H
#include "../../ArvoreBinaria.h"

pNohArvore obterMinimo(pNohArvore noh) {
    while (noh->esquerda != NULL)
        noh = noh->esquerda;
    return noh;
}

pNohArvore excluirInfoRecursivo(pNohArvore raiz, void *info, FuncaoComparacao fc) {
    if (raiz == NULL)
        return NULL;

    int comp = fc(raiz->info, info);

    if (comp > 0)
        raiz->esquerda = excluirInfoRecursivo(raiz->esquerda, info, fc);
    else if (comp < 0)
        raiz->direita = excluirInfoRecursivo(raiz->direita, info, fc);
    else {
        if (raiz->esquerda == NULL) {
            pNohArvore temp = raiz->direita;
            free(raiz->info);
            free(raiz);
            return temp;
        } else if (raiz->direita == NULL) {
            pNohArvore temp = raiz->esquerda;
            free(raiz->info);
            free(raiz);
            return temp;
        }

        pNohArvore temp = obterMinimo(raiz->direita);
        raiz->info = temp->info;
        raiz->direita = excluirInfoRecursivo(raiz->direita, temp->info, fc);
    }

    return raiz;
}

int excluirInfo(pDArvore arvore, void *info, FuncaoComparacao pfc) {
    if (arvore->raiz == NULL)
        return 0;

    arvore->raiz = excluirInfoRecursivo(arvore->raiz, info, pfc);
    return 1;
}

#endif
