#ifndef STRUCT_ARVORE_H
#define STRUCT_ARVORE_H
#include "../../ArvoreBinaria.h"
struct nohArvore{
   void*              info;
   struct nohArvore  *esquerda;
   struct nohArvore  *direita;
};

#endif
