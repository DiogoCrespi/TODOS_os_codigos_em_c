#ifndef BUSCAR_INFO_H
#define BUSCAR_INFO_H
#include "../../ArvoreBinaria.h"

pNohArvore buscarInfoRecursivo(pNohArvore raiz, void *info, FuncaoComparacao pfc) {
    if (raiz == NULL || pfc(raiz->info, info) == 0)
        return raiz;

    if (pfc(raiz->info, info) > 0)
        return buscarInfoRecursivo(raiz->esquerda, info, pfc);
    else
        return buscarInfoRecursivo(raiz->direita, info, pfc);
}

pNohArvore buscarInfo(pDArvore arvore, void *info, FuncaoComparacao pfc) {
    if (arvore == NULL || arvore->raiz == NULL)
        return NULL;

    return buscarInfoRecursivo(arvore->raiz, info, pfc);
}

#endif

