#ifndef AMPLITUDE_H
#define AMPLITUDE_H

#include "../../ArvoreBinaria.h"
#include "../../../Cap3/Lista.h"

void amplitude(pDArvore arvore, FuncaoImpressao fi) {
    if (arvore == NULL || arvore->raiz == NULL)
        return;

    pDLista lista = criarLista();
    adicionarFim(lista, arvore->raiz);

    while (!listaVazia(lista)) {
        pNohArvore nohAtual = removerInicio(lista);
        fi(nohAtual->info);

        if (nohAtual->esquerda != NULL) {
            adicionarFim(lista, nohAtual->esquerda);
        }

        if (nohAtual->direita != NULL) {
            adicionarFim(lista, nohAtual->direita);
        }
    }

    liberarLista(lista);
}

#endif
