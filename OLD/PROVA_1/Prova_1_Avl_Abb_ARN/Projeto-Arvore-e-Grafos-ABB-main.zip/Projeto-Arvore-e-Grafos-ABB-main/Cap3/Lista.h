#include "TAD_ListaLinear.h"

#include "Operacoes/1_Structs.h"

#include "Operacoes/2_CriarLista.h"

#include "Operacoes/3_IncluirInfo.h"

#include "Operacoes/4_IncluirInfoInicio.h"

#include "Operacoes/5_IncluirInfoMeio.h"

#include "Operacoes/6_ExcluirInfo.h"

#include "Operacoes/7_ExcluirInfoPos.h"

#include "Operacoes/8_ContemInfo.h"

#include "Operacoes/9_ImprimirLista.h"

#include "Operacoes/10_DestruirLista.h"

#include "Operacoes/11_DuplicarLista.h"

#include "Operacoes/12_DividirLista.h"

#include "Operacoes/13_UnirListas.h"

#include "Operacoes/14_BuscarNoInfo.h"

#include "Operacoes/15_BuscarInfoPos.h"

#include "Operacoes/16_InverterLista.h"