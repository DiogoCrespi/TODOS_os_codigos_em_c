struct noh{
   <tipo_dado>   info;
   struct noh   *prox;
};
